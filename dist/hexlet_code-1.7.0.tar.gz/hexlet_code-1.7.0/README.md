### Hexlet tests and linter status:
[![Actions Status](https://github.com/hsuez/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/hsuez/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/5e18598265227c42c4d9/maintainability)](https://codeclimate.com/github/hsuez/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/5e18598265227c42c4d9/test_coverage)](https://codeclimate.com/github/hsuez/python-project-49/test_coverage)
