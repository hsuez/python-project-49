#!/usr/bin/env python3
import sys
import brain_games.scripts.cli_backup

def main():
    print("Welcome to the Brain Games!")
    brain_games.scripts.cli_backup.welcome_user()


if __name__ == "__main__":
    main()
